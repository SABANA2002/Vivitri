n=int(input("Enter number:"))
for i in range(1,n+1):
    for j in range(1,n-i+2):
        if(j==n-i+1):
            print(j,end="")
        else:    
            print(j,"*",end="")
    print()