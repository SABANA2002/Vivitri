a,b=map(int,input().split(','))
arr=[[0 for col in range(b)] for row in range(a)]
for i in range(a):
    for j in range(b):
        arr[i][j]=i*j
print(arr)