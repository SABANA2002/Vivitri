n=int(input("Enter number: "))
for i in range(1,n+1):
    for j in range(n-i+1,n):
        print(" ",end="")
    for j in range(n,i-1,-1):
        print(j,end=" ")
    if(i!=1):
        if(i==2):
            for j in range(0,2):
                print(" ",end="")
        if(i!=2):
            for j in range(2,2*i):
                print(" ",end="")
    for j in range(i,n+1):
        print(j,end=" ")
    print()