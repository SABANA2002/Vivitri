s=input(" ")
import re
l=s.split(",")
for i in l:
    if(len(i)>=6 and len(i)<=12):
        if re.search("([a-z])+", i):
            if re.search("([A-Z])+", i):
                if re.search("([0-9])+", i):
                    if re.search("([#,@,$])+", i):
                        print(i)