sab = input()
word = sab.split()
words = {}
for word in sab.split():
    words[word] = words.get(word,0) + 1

for i in sorted(words):
    print("{} : {}".format(i,words[i]))