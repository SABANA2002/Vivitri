l=input()
k=int(input())
l=l.split()
for i in range(len(l)):
    if(len(l[i])>k):
        print(l[i],end=',')