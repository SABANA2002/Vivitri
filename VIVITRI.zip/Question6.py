str1 = input("str1: ")
str2 = input("str2: ")

words = {}
for word in str1.split():
    words[word] = words.get(word, 0) + 1
for word in str2.split():
    words[word] = words.get(word, 0) + 1
  
res =  [word for word in words if words[word] == 1]
print(res)