l=input()

str1 = ''
str1 += l[0].lower()
for i in range(1, len(l)):
    if (l[i] == ' '):
        str1 += l[i + 1].upper()
        i += 1
    elif(l[i - 1] != ' '):
        str1 += l[i]
print(str1)